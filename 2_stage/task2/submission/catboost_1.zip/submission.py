import pandas as pd

def eval(data):
    return pd.read_csv('test.csv').to_csv()
