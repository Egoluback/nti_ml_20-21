import pandas as pd

def eval(data):
    return pd.read_csv('prank2.csv').to_csv()